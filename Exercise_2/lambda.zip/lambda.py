import os

def lambda_handler(event, context):
        print("hello from Lambda")
   

